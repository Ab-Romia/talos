from pydantic import BaseModel
from fastapi_users import schemas
import uuid
from datetime import date
from typing import Optional

class PostCreate(BaseModel):
    title: str
    content: str


class PostResponse(BaseModel):
    title: str
    content: str



class UserRead(schemas.BaseUser[uuid.UUID]):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    region: Optional[str] = None

class UserCreate(schemas.BaseUserCreate):
    first_name: str
    last_name: str
    date_of_birth: date
    region: str

class UserUpdate(schemas.BaseUserUpdate):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    region: Optional[str] = None