import uvicorn #webserver 

if __name__ == "__main__":
    uvicorn.run(app="app.app:app", host="0.0.0.0", port=8000, reload=True)
    #running api on local host