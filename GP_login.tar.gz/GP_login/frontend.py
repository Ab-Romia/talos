
import streamlit as st
import requests
import base64
import urllib.parse
import datetime

st.set_page_config(page_title="Project name ", layout="wide", page_icon="💜")


PAGE_CSS = """
<style>
/* Page background gradient */
[data-testid="stAppViewContainer"] > .main {
  background: linear-gradient(135deg, #1f0932 0%, #3a0ca3 35%, #ff6fb1 100%);
  min-height: 100vh;
  padding-bottom: 50px;
  color: #fff;
}

/* Card style for sections */
.card {
  background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(0,0,0,0.06));
  border-radius: 12px;
  padding: 16px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.25);
  margin-bottom: 16px;
  color: #fff;
  border: 1px solid rgba(255,255,255,0.06);
}

/* Header */
.header {
  padding: 24px;
  border-radius: 12px;
  background: linear-gradient(90deg, rgba(255,111,177,0.12), rgba(122,0,255,0.12));
  margin-bottom: 20px;
}

/* Buttons */
.stButton>button {
  background: linear-gradient(90deg, #ff6fb1, #8b5cf6) !important;
  color: white;
  border: none;
  padding: 8px 14px;
  border-radius: 10px;
  box-shadow: 0 6px 16px rgba(139,92,246,0.25);
}

/* Secondary (outline) */
.stButton.secondary>button {
  background: transparent !important;
  color: #fff !important;
  border: 1px solid rgba(255,255,255,0.15) !important;
  box-shadow: none;
}

/* File uploader / textarea tweaks */
.stFileUploader>div, textarea, input {
  border-radius: 8px;
}

/* Post image rounded */
.post-media {
  border-radius: 12px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,0.06);
}

/* Small gray text */
.small {
  color: rgba(255,255,255,0.7);
  font-size: 13px;
}

/* Delete button small */
.delete-btn {
  background: transparent !important;
  border: none;
  color: rgba(255,255,255,0.9) !important;
}

/* center the login card */
.center {
  display: flex;
  align-items: center;
  justify-content: center;
}
.forgot-link {
  margin-top: 6px;
  margin-bottom: 6px;
  font-size: 14px;
}




/* make sure side-by-side buttons look good on wide and narrow screens */
.button-row .stButton > button {
  width: 100%;
  display: inline-block;
  box-sizing: border-box;
}
.button-row .stButton {
  padding: 0 6px;
}





</style>
"""

st.markdown(PAGE_CSS, unsafe_allow_html=True)

# -------------------------
# Session state
# -------------------------
if "token" not in st.session_state:
    st.session_state.token = None
if "user" not in st.session_state:
    st.session_state.user = None

if "show_forgot_password" not in st.session_state:
    st.session_state.show_forgot_password = False
#
if "show_signup_page" not in st.session_state:
    st.session_state.show_signup_page = False

API_BASE = "http://localhost:8000"

# -------------------------
# Helpers
# -------------------------
def get_headers():
    if st.session_state.token:
        return {"Authorization": f"Bearer {st.session_state.token}"}
    return {}

def encode_text_for_overlay(text):
    if not text:
        return ""
    base64_text = base64.b64encode(text.encode("utf-8")).decode("utf-8")
    return urllib.parse.quote(base64_text)

def create_transformed_url(original_url, transformation_params, caption=None):
    if caption:
        encoded_caption = encode_text_for_overlay(caption)
        text_overlay = f"l-text,ie-{encoded_caption},ly-N20,lx-20,fs-100,co-white,bg-000000A0,l-end"
        transformation_params = text_overlay

    if not transformation_params:
        return original_url

    parts = original_url.split("/")
    if len(parts) < 5:
        return original_url
    imagekit_id = parts[3]
    file_path = "/".join(parts[4:])
    base_url = "/".join(parts[:4])
    return f"{base_url}/tr:{transformation_params}/{file_path}"

# -------------------------
# UI pieces
# -------------------------
def header():
    st.markdown(
        """
        <div class="header">
          <h1 style="margin:0; font-size:28px;">💜 Project name</h1>
          <div class="small">AI-augmented Collaborative Platform:
For project management and team collaboration with a context-aware AI assistant to enhance team productivity using advanced RAG and agentic AI.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

def login_page():
    header()
    st.markdown('<div class="card center" style="max-width:900px;">', unsafe_allow_html=True)

    left, right = st.columns([1.4, 1])

    with left:
        st.subheader("Welcome back")
        st.write("Sign in to continue ✨")
        email = st.text_input("Email:", key="login_email", placeholder="you@example.com")
        password = st.text_input("Password:", key="login_password", type="password")

        # st.markdown('<div class="forgot-link link-like-button">', unsafe_allow_html=True)
        # if st.button("Forgot your password?", key="forgot_link"):
        #     st.session_state.show_forgot_password = True
        #     st.rerun()
        # st.markdown('</div>', unsafe_allow_html=True)

        st.markdown("<div class='forgot-link' style='margin-top:6px; margin-bottom:6px;'>", unsafe_allow_html=True)
        if st.button("Forgot your password?", key="forgot_link"):
            st.session_state.show_forgot_password = True
            st.rerun()
        st.markdown("</div>", unsafe_allow_html=True)


        # Buttons on the same line: use columns inside a wrapper div
        # The wrapper div helps with our .button-row CSS
        st.markdown('<div class="button-row">', unsafe_allow_html=True)
        col_left_btn, col_right_btn = st.columns([1, 1])
        with col_left_btn:
            if st.button("Login", key="login", use_container_width=True):
                if not (email and password):
                    st.error("Enter email and password.")
                else:
                    login_data = {"username": email, "password": password}
                    try:
                        response = requests.post(f"{API_BASE}/auth/jwt/login", data=login_data, timeout=8)
                    except Exception as e:
                        st.error("Couldn't reach backend.")
                        return

                    if response.status_code == 200:
                        token_data = response.json()
                        st.session_state.token = token_data["access_token"]
                        user_response = requests.get(f"{API_BASE}/auth/me", headers=get_headers())
                        if user_response.status_code == 200:
                            st.session_state.user = user_response.json()
                            st.rerun()
                        else:
                            st.error("Failed to get user info")
                    else:
                        st.error("Invalid email or password!")

        with col_right_btn:
            # show sign up as secondary visually by using CSS or separate class — we keep same style but it will be side-by-side
            if st.button("Sign Up", key="signup", use_container_width=True):
                st.session_state.show_signup_page = True
                st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)

    with right:
        st.subheader("Project Name")
        st.markdown(
            """
            -  features
            """,
            unsafe_allow_html=True,
        )
        st.markdown('<div style="height:8px"></div>', unsafe_allow_html=True)
        st.image(
            "https://images.unsplash.com/photo-1531891437562-430c0d6e3b7a?auto=format&fit=crop&w=800&q=60",
            caption="Vibe board",
            width=400,
        )

    st.markdown("</div>", unsafe_allow_html=True)

def signup_page():
    header()
    st.markdown('<div class="card center" style="max-width:700px;">', unsafe_allow_html=True)

    st.subheader("Create Your Account ✨")
    st.write("Join our platform today!")

    # Name fields
    col1, col2 = st.columns(2)
    with col1:
        first_name = st.text_input("First Name:", key="signup_first_name", placeholder="John")
    with col2:
        last_name = st.text_input("Last Name:", key="signup_last_name", placeholder="Doe")

    # Date of birth
    date_of_birth = st.date_input(
        "Date of Birth:",
        key="signup_dob",
        min_value=datetime.date(1900,1,1),
        max_value=datetime.date.today(),
        value=None
    )

    # Region
    region = st.selectbox(
        "Region:",
        key="signup_region",
        options=[
            "",  # Empty option
            "North America",
            "South America",
            "Europe",
            "Asia",
            "Africa",
            "Australia/Oceania",
            "Middle East"
        ],
        index=0
    )

    # Email and password
    email = st.text_input("Email:", key="signup_email", placeholder="you@example.com")
    
    col3, col4 = st.columns(2)
    with col3:
        password = st.text_input("Password:", key="signup_password", type="password", placeholder="Min 8 characters")
    with col4:
        confirm_password = st.text_input("Confirm Password:", key="signup_confirm_password", type="password", placeholder="Re-enter password")

    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)

    # Sign up button
    if st.button("Create Account", key="do_signup", use_container_width=True):
        # Validation
        if not all([first_name, last_name, date_of_birth, region, email, password, confirm_password]):
            st.error("Please fill in all fields.")
        elif password != confirm_password:
            st.error("Passwords do not match!")
        elif len(password) < 8:
            st.error("Password must be at least 8 characters long.")
        elif not region:
            st.error("Please select a region.")
        else:
            # Prepare signup data
            signup_data = {
                "email": email,
                "password": password,
                "first_name": first_name,
                "last_name": last_name,
                "date_of_birth": date_of_birth.isoformat(),  # Convert date to string
                "region": region
            }
            
            try:
                response = requests.post(
                    f"{API_BASE}/auth/register",
                    json=signup_data,
                    timeout=8
                )
                
                if response.status_code in (200, 201):
                    st.success("✅ Account created successfully!")
                    st.info("Redirecting to login page...")
                    st.session_state.show_signup_page = False
                    # Wait a moment before redirect
                    import time
                    time.sleep(1.5)
                    st.rerun()
                else:
                    detail = response.json().get("detail", "Registration failed")
                    if isinstance(detail, list):
                        for error in detail:
                            st.error(f"{error.get('msg', 'Error')}")
                    else:
                        st.error(f"Registration failed: {detail}")
            except Exception as e:
                st.error(f"Couldn't reach backend: {str(e)}")

    st.markdown("<div style='height:12px'></div>", unsafe_allow_html=True)

    # Back to login button
    if st.button("← Already have an account? Login", key="back_to_login_from_signup", use_container_width=True):
        st.session_state.show_signup_page = False
        st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)


def forgot_password_page():
    header()
    st.markdown('<div class="card center" style="max-width:600px;">', unsafe_allow_html=True)
    
    st.subheader("Forgot Password? 🔑")
    st.write("Enter your email to receive a password reset token.")
    
    email = st.text_input("Email:", key="forgot_email", placeholder="you@example.com")
    
    if st.button("Send Reset Token", key="request_reset", use_container_width=True):
        if not email:
            st.error("Please enter your email.")
        else:
            try:
                response = requests.post(
                    f"{API_BASE}/auth/forgot-password",
                    json={"email": email},
                    timeout=8
                )
                if response.status_code == 202:
                    st.success("✅ Reset token sent! Check your console/logs for the token.")
                    st.info("⚠️ Note: In development, the token is printed in the backend terminal, not sent via email.")
                else:
                    st.error("Failed to send reset token.")
            except Exception:
                st.error("Couldn't reach backend.")
    
    st.markdown("---")
    
    st.subheader("Reset Password")
    st.write("Enter the reset token and your new password.")
    
    token = st.text_input("Reset Token:", key="reset_token", placeholder="Token from email/console")
    new_password = st.text_input("New Password:", key="new_password", type="password")
    
    if st.button("Reset Password", key="do_reset", use_container_width=True):
        if not (token and new_password):
            st.error("Please enter both token and new password.")
        else:
            try:
                response = requests.post(
                    f"{API_BASE}/auth/reset-password",
                    json={"token": token, "password": new_password},
                    timeout=8
                )
                if response.status_code == 200:
                    st.success("✅ Password reset successful! You can now login.")
                else:
                    detail = response.json().get("detail", "Reset failed")
                    st.error(f"Reset failed: {detail}")
            except Exception:
                st.error("Couldn't reach backend.")
    
    if st.button("← Back to Login", key="back_to_login"):
        st.session_state.show_forgot_password = False
        st.rerun()
    
    st.markdown("</div>", unsafe_allow_html=True)


def upload_page():
    header()
    st.markdown('<div class="card" style="max-width:900px;">', unsafe_allow_html=True)
    st.subheader("Share something beautiful 💫")
    uploaded_file = st.file_uploader("Choose media", type=["png","jpg","jpeg","mp4","avi","mov","mkv","webm"])
    caption = st.text_area("Caption:", placeholder="What's on your mind?")

    if uploaded_file and st.button("Share", key="share"):
        with st.spinner("Uploading..."):
            files = {"file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
            data = {"caption": caption}
            try:
                response = requests.post(f"{API_BASE}/upload", files=files, data=data, headers=get_headers(), timeout=20)
            except Exception:
                st.error("Upload failed (server unreachable).")
                return

            if response.status_code == 200:
                st.success("Posted!")
                st.rerun()
            else:
                st.error("Upload failed!")

    st.markdown("</div>", unsafe_allow_html=True)

def feed_card(post):
    # Build a custom HTML card for the post
    email = post.get("email", "unknown")
    created_at = post.get("created_at", "")[:10]
    caption = post.get("caption", "")
    is_owner = post.get("is_owner", False)
    media_type = post.get("file_type", "image")
    url = post.get("url", "")

    # Choose a safe display url using the transformation helper (caption overlay for images)
    if media_type == "image":
        media_url = create_transformed_url(url, "", caption)
        media_html = f'<img class="post-media" src="{media_url}" width="100%" />'
    else:
        # for videos use original url (some CDNs block embedding - fallback to st.video when possible)
        media_html = f'<video class="post-media" controls style="width:100%;max-height:360px"><source src="{url}"></video>'

    delete_button_html = ""
    if is_owner:
        delete_button_html = f'''
            <form action="#" method="POST" style="display:inline;">
                <button class="delete-btn" title="Delete post">🗑️</button>
            </form>
        '''

    card_html = f"""
    <div class="card">
      <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <strong>{email}</strong>
            <div class="small">{created_at}</div>
          </div>
          <div>{delete_button_html}</div>
      </div>
      <div style="margin-top:12px;">
        {media_html}
      </div>
      <div style="margin-top:10px;">
        <div style="font-size:15px; color: #fff">{caption}</div>
      </div>
    </div>
    """
    st.markdown(card_html, unsafe_allow_html=True)

def feed_page():
    header()
    st.markdown('<div style="max-width:1000px;">', unsafe_allow_html=True)
    try:
        response = requests.get(f"{API_BASE}/feed", headers=get_headers(), timeout=8)
    except Exception:
        st.error("Couldn't load feed (server unreachable).")
        st.markdown("</div>", unsafe_allow_html=True)
        return

    if response.status_code == 200:
        posts = response.json().get("posts", [])
        if not posts:
            st.info("No posts yet — be the first to share! 💖")
        for post in posts:
            feed_card(post)
    else:
        st.error("Failed to load feed.")
    st.markdown("</div>", unsafe_allow_html=True)

# -------------------------
# Main
# -------------------------
#if st.session_state.user is None:
    #login_page()

if st.session_state.user is None:
    if st.session_state.show_forgot_password:
        forgot_password_page()
    elif st.session_state.show_signup_page:
        signup_page()
    else:
        login_page()
else:
    # left sidebar
    st.sidebar.markdown("<div style='padding:8px; font-weight:600; color:#fff'>👋 Hi {}</div>".format(st.session_state.user["email"]), unsafe_allow_html=True)
    if st.sidebar.button("Logout"):
        st.session_state.user = None
        st.session_state.token = None
        st.rerun()

    st.sidebar.markdown("---", unsafe_allow_html=True)
    page = st.sidebar.radio("Navigate:", ["🏠 Feed", "📸 Upload"], index=0)

    # show current page
    if page == "🏠 Feed":
        feed_page()
    else:
        upload_page()
